-Artsiom Skarakhod
-How to launch:
	1) type: make  <-- this makes the cpp file
	2) type: ./sched <enterYourTextFileNameHere> <0-3 for sched algos> <if doing RR then put a number which will be used as quantum>
-All of the screenshots are in the pdf file called screenshots.pdf
-This program has been tested on Windows and Linux enviroments and worked every single time, if you run into any difficulties please message me :)


